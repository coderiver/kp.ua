1. http://www.kp.ru/
2. http://www.kp.ru/online/                     OK
3. http://www.kp.ru/politics
4. http://www.kp.ru/daily/elections2012/
5. http://www.kp.ru/daily/26001.4/2928090/
6. http://www.kp.ru/daily/press/
7. http://www.kp.ru/daily/press/detail/10596/  
8. http://www.kp.ru/daily/friday/               OK
9. http://www.kp.ru/action
10. http://www.kp.ru/about/                     OK
11. http://www.kp.ru/photo/
12. http://www.kp.ru/video/
13. http://www.kp.ru/video/484608/